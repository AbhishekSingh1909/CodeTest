﻿using System;
using System.Web.Mvc;

namespace WebCodeTestMVC.Controllers
{
    public class TestController : Controller
    {
        // GET: Test
        public ActionResult Index()
        {
            return View();
        }
    }
}